package com.ecommerce.backend.jpa.test;

import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@SelectPackages({"com.ecommerce.backend.jpa.repository", "com.ecommerce.backend.jpa.services" })
@Suite
public class JUNITTestSuite {

	
	
	
}